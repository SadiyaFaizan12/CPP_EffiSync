#include "mainwindow.h"
#include "qdatetime.h"
#include "qtimer.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->groupBox_2->hide();
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(changeQuote()));
    quotes[0] = "The only way to do great work is to love what you do. - Steve Jobs";
    quotes[1] = "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle. - Christian D. Larson";
    quotes[2] = "Don't watch the clock; do what it does. Keep going. - Sam Levenson";
    quotes[3] = "You are never too old to set another goal or to dream a new dream. - C.S. Lewis";
    quotes[4] = "The secret to getting ahead is getting started. - Mark Twain";
    quotes[5] = "Believe you can and you're halfway there. - Theodore Roosevelt";
    quotes[6] = "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill";
    quotes[7] = "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt";
    quotes[8] = "You miss 100% of the shots you don't take. - Wayne Gretzky";
    quotes[9] = "The best way to predict the future is to invent it. - Alan Kay";
    quotes[10] = "It's not whether you get knocked down, it's whether you get up. - Vince Lombardi";
    quotes[11] = "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt";
    quotes[12] = "The only person you should try to be better than is the person you were yesterday. - Anonymous";
    quotes[13] = "Hardships often prepare ordinary people for an extraordinary destiny. - C.S. Lewis";
    quotes[14] = "In the middle of every difficulty lies opportunity. - Albert Einstein";
    quotes[15] = "It always seems impossible until it's done. - Nelson Mandela";
    quotes[16] = "The only thing standing between you and your goal is the story you keep telling yourself as to why you can't achieve it. - Jordan Belfort";
    quotes[17] = "You are never too old to set another goal or to dream a new dream. - C.S. Lewis";
    quotes[18] = "It does not matter how slowly you go as long as you do not stop. - Confucius";
    quotes[19] = "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt";

}

MainWindow::~MainWindow()
{
    delete ui;
}
QHash<QDate, QVector<QVector<QString>>> myHash; // hash with date as keys and nested vec as value for reminders



void MainWindow::on_pushButton_addrem_clicked() // to add reminders
{
    ui->remin->clear();

    QString title = ui->title->text();
    QString description = ui->desc->text();
    QTime time = ui->t1->time();
    QString strTime=time.toString("hh:mm:ss");
    QString email = ui->email->text();
    QDate date = ui->calendarWidget->selectedDate();
    QString formattedDate = date.toString("yyyy-MM-dd");
    QString dataString;
    dataString = QString();
    QVector<QString> dataArray; //vector with string of reminder details

    dataArray.append(title);
    dataArray.append(description);
    dataArray.append(strTime);
    dataArray.append(email);

    QVector<QVector<QString>> dateArray; // nested vector with string inside inner vector


    dateArray.append(dataArray);

    myHash[date]=dateArray;

    QVector<QVector<QString>> value = myHash.value(date); //value stores vector with reminders of a date

    for (const QVector<QString> &inner:value) //
    {
        dataString+="Date : "+formattedDate+"\n";
        dataString+="Title : "+inner[0]+"\n";
        dataString+="Description : "+inner[1]+"\n";
        dataString+="Time : "+inner[2]+"\n";
        dataString+="Email : "+inner[3]+"\n\n";
    }
    ui->remin->setText(dataString);
    ui->title->clear();
    ui->desc->clear();
    ui->email->clear();
    ui->lineEdit_6->clear();
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::on_calendarWidget_clicked(const QDate &date) //to show reminders of date selected on calender
{
    ui->remin->clear();


    QString dataString;
    QVector<QVector<QString>> value = myHash.value(date);
    QString formattedDate = date.toString("yyyy-MM-dd");
    if (!value.isEmpty())
    {
        for (const QVector<QString> &inner:value)
        {
            dataString+="Date : "+formattedDate+"\n";
            dataString+="Title : "+inner[0]+"\n";
            dataString+="Description : "+inner[1]+"\n";
            dataString+="Time : "+inner[2]+"\n";
            dataString+="Email : "+inner[3]+"\n\n";
        }
        ui->remin->setText(dataString); // to show reminders of the selected date
    }
}

void MainWindow::on_pushButton_6_clicked() // to search reminder
{
    ui->remin->clear();

    int count=0; //to count number of matched reminders
    QString reminder; //to store reminder
    QString title = ui->lineEdit_6->text(); //take title of reminder
    QHash<QDate, QVector<QVector<QString>>>::const_iterator it; //to create a Qhash iterator it
    for (it = myHash.constBegin(); it != myHash.constEnd(); ++it) //to iterate thru all dates
    {
        QDate key = it.key(); //get the date
        QString formattedDate = key.toString("yyyy-MM-dd"); // Define the format you want
        QVector<QVector<QString>> value = it.value(); //get all the reminders for that date
        for (const QVector<QString> &inner:value) //to iterate thru each reminder of a date 'key'
        {
            QString title_1=inner[0];
            if (title_1==title)
            {
                count+=1;
                reminder+="Date : "+formattedDate+"\n";
                reminder+="Title : "+inner[0]+"\n";
                reminder+="Description : "+inner[1]+"\n";
                reminder+="Time : "+inner[2]+"\n";
                reminder+="Email : "+inner[3]+"\n\n";
            }
        }
    }
    if (count>0)
    {
        ui->remin->setText(reminder);
    }
    else
    {
        ui->remin->setText("No reminders found");
    }
    //ui->lineEdit_6->clear();
}

void MainWindow::on_pushButton_3_clicked() // to delete reminder
{
    ui->remin->clear();
    QString title = ui->lineEdit_6->text(); // title of reminder to delete
    int count = 0; // number of deleted reminders

    QHash<QDate, QVector<QVector<QString>>>::iterator it_del; // Use a non-const iterator to modify the hash
    for (it_del = myHash.begin(); it_del != myHash.end(); /* no need to increment here */) // Iterate through all dates
    {
        QVector<QVector<QString>>& value = it_del.value(); // Get all the reminders for that date by reference
        QVector<QVector<QString>>::iterator innerIt = value.begin(); // iterator for value vector
        while (innerIt != value.end()) // Iterate through each reminder of a date 'key'
        {
            QString title_1 = (*innerIt)[0];
            if (title_1 == title)
            {
                innerIt = value.erase(innerIt); // Remove the inner vector if title matches
                ++count;
            }
            else
            {
                ++innerIt;
            }
        }
        // Remove the date entry if all reminders for that date were deleted
        if (value.isEmpty())
        {
            it_del = myHash.erase(it_del);
        }
        else
        {
            ++it_del; // Move to the next date
        }
    }

    if (count > 0)
    {
        QString fin = QString::number(count);
        ui->remin->setText(fin + " reminder(s) deleted.");
    }
    else
    {
        ui->remin->setText("No reminders found.");
    }
    ui->lineEdit_6->clear();
}

void MainWindow::on_pushButton_4_clicked() //to edit reminder
{
    ui->groupBox_2->show();
    this->resize(1250, 600);
    int count=0;
    ui->remin->clear();
    QString title = ui->lineEdit_6->text(); //take title of reminder
    QHash<QDate, QVector<QVector<QString>>>::const_iterator it; //to create a Qhash iterator it
    for (it = myHash.constBegin(); it != myHash.constEnd(); ++it) //to iterate thru all dates
    {
        QDate key = it.key(); //get the date
        QVector<QVector<QString>> value = it.value(); //get all the reminders for that date
        for (const QVector<QString> &inner:value) //to iterate thru each reminder of a date 'key'
        {
            QString title_1=inner[0];
            if (title_1==title)
            {
                count+=1;
                ui->lineEdit->setText(inner[0]);//title
                ui->lineEdit_3->setText(inner[1]);//desc
                ui->timeEdit_3->setTime(QTime::fromString(inner[2])); //time
                ui->lineEdit_4->setText(inner[3]);//email
                break;
            }
        }
        if (count==1)
        {
            break;
        }
    }
}

void MainWindow::on_pushButton_7_clicked() //to update reminder
{
    ui->remin->clear();
    QString title = ui->lineEdit_6->text(); // title of reminder to delete
    //int count = 0; // number of deleted reminders

    QHash<QDate, QVector<QVector<QString>>>::iterator it_del; // Use a non-const iterator to modify the hash
    for (it_del = myHash.begin(); it_del != myHash.end(); /* no need to increment here */) // Iterate through all dates
    {
        QVector<QVector<QString>>& value = it_del.value(); // Get all the reminders for that date by reference
        QVector<QVector<QString>>::iterator innerIt = value.begin(); // iterator for value vector
        while (innerIt != value.end()) // Iterate through each reminder of a date 'key'
        {
            QString title_1 = (*innerIt)[0];
            if (title_1 == title)
            {
                innerIt = value.erase(innerIt); // Remove the inner vector if title matches
                //++count;
            }
            else
            {
                ++innerIt;
            }
        }
        // Remove the date entry if all reminders for that date were deleted
        if (value.isEmpty())
        {
            it_del = myHash.erase(it_del);
        }
        else
        {
            ++it_del; // Move to the next date
        }
    }

    ui->remin->clear();

    QString title2 = ui->lineEdit->text();
    QString description2 = ui->lineEdit_3->text();
    QTime time2 = ui->timeEdit_3->time();
    QString strTime=time2.toString("hh:mm:ss");
    QString email2 = ui->lineEdit_4->text();
    QDate date = ui->calendarWidget->selectedDate();
    QString formattedDate = date.toString("yyyy-MM-dd");
    QString dataString;
    dataString = QString();
    QVector<QString> dataArray; //vector with string of reminder details

    dataArray.append(title2);
    dataArray.append(description2);
    dataArray.append(strTime);
    dataArray.append(email2);

    QVector<QVector<QString>> dateArray; // nested vector with string inside inner vector


    dateArray.append(dataArray);

    myHash[date]=dateArray;

    QVector<QVector<QString>> value = myHash.value(date); //value stores vector with reminders of a date

    for (const QVector<QString> &inner:value) //
    {
        dataString+="Date : "+formattedDate+"\n";
        dataString+="Title : "+inner[0]+"\n";
        dataString+="Description : "+inner[1]+"\n";
        dataString+="Time : "+inner[2]+"\n";
        dataString+="Email : "+inner[3]+"\n\n";
    }
    ui->label_11->setText(dataString);
    ui->remin->setText("Updated successfully");
}

void MainWindow::on_pushButton_5_clicked() //cancel update
{
    ui->groupBox_2->hide();
    this->resize(980, 600);
}

void MainWindow::on_pushButton_8_clicked() //close after update
{
    ui->groupBox_2->hide();
    this->resize(980, 600);
    ui->label_11->clear();
}



void MainWindow::changeQuote()
{
    // Generate a random index to select a quote
    int index = QTime::currentTime().msec() % 20; // 20 is the size of the array

    // Set the randomly selected quote on the QLabel
    ui->label->setText(quotes[index]);
}

void MainWindow::on_pushButton_changequote_clicked()
{
    changeQuote();
}

