#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QDateTime>
#include <QDebug>



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->label->setText("Weather: ");

    fetchWeatherData();
    dateTimeLabel = ui->label1;

    if(dateTimeLabel) {
        // Create a timer to update the time every second
        timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &MainWindow::updateTime);
        timer->start(1000); // Update every 1000 milliseconds (1 second)

        // Update the time immediately
        updateTime();
    } else {
        qDebug() << "Label not found!";
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::fetchWeatherData()
{
    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    connect(manager, &QNetworkAccessManager::finished, this, &MainWindow::onWeatherDataReceived);

    // Replace "YOUR_API_KEY" with your OpenWeatherMap API key
    QString apiKey = "c8e2df94491adbde9bb93df1271efea6";
    QString city = "Noida";
    QString urlStr = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey;


    QUrl url(urlStr);
    QNetworkRequest request(url);

    manager->get(request);
}

void MainWindow::onWeatherDataReceived(QNetworkReply *reply)
{
    if (reply->error() == QNetworkReply::NoError) {
        QByteArray responseData = reply->readAll();
        QJsonDocument jsonResponse = QJsonDocument::fromJson(responseData);

        if (!jsonResponse.isNull()) {
            QJsonObject jsonObj = jsonResponse.object();

            if (jsonObj.contains("main") && jsonObj["main"].isObject()) {
                double temperatureKelvin = jsonObj["main"].toObject()["temp"].toDouble();
                double temperatureCelsius = temperatureKelvin - 273.15;

            QJsonValue weatherValue = jsonObj["weather"].toArray()[0].toObject()["description"];
            QString weatherDesc = weatherValue.toString();

            QLabel *weatherLabel = ui->label;
            if (weatherLabel) {
                QString displayText = "Temperature: " + QString::number(temperatureCelsius, 'f', 2) + "°C\n";
                                      displayText += "Weather: " + weatherDesc;
                weatherLabel->setText(displayText);
            }

            // Display the weather description on the label

        }
    } else {
        qDebug() << "Error: " << reply->errorString();
    }

    reply->deleteLater();
    }
}

void MainWindow::updateTime()
{
    if(dateTimeLabel) {
    // Get current date and time
    QDateTime currentDateTime = QDateTime::currentDateTime();

    // Display date and time in a specific format
    QString dateTimeStr = currentDateTime.toString("yyyy-MM-dd hh:mm:ss");

    // Update the label with the current date and time
    dateTimeLabel->setText(dateTimeStr);
    }
}



