#ifndef EVENTDIALOG_H
#define EVENTDIALOG_H
#include <QDialog>
#include <QDateEdit>
#include <QLineEdit>
#include <QPushButton>

class EventDialog : public QDialog
{
    Q_OBJECT

public:
    EventDialog(QWidget *parent = nullptr);
    ~EventDialog();

private:
    QDateEdit *dateEdit;
    QLineEdit *descriptionEdit;
    QPushButton *okButton;
    QPushButton *cancelButton;

private slots:
    void accept();
};

#endif // EVENTDIALOG_H
