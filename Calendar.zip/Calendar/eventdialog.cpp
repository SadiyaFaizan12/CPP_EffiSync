#include <QVBoxLayout>
#include "eventdialog.h"
#include "qwidget.h"
EventDialog::EventDialog(QWidget *parent)
    : QDialog(parent)
{
    dateEdit = new QDateEdit(this);
    descriptionEdit = new QLineEdit(this);
    okButton = new QPushButton("OK", this);
    cancelButton = new QPushButton("Cancel", this);

    connect(okButton, SIGNAL(clicked()), this, SLOT(accept()));
    connect(cancelButton, SIGNAL(clicked()), this, SLOT(reject()));



    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(dateEdit);
    layout->addWidget(descriptionEdit);
    layout->addWidget(okButton);
    layout->addWidget(cancelButton);

    setLayout(layout);
}
EventDialog::~EventDialog()
{
}

void EventDialog::accept()
{
    QDialog::accept();
}
