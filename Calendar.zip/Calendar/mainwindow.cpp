#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    addEventButton=new QPushButton("Add Event",this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// By this event we can get the selected date from the calendar
void MainWindow::on_calendarWidget_clicked(const QDate &date)
{
    qDebug() <<"Selected Date :"<<date;
}

//By this event you can get the selected year and month from the calendar
void MainWindow::on_calendarWidget_currentPageChanged(int year, int month)
{
   qDebug() <<"Selected Year :"<<year;
   qDebug() <<"Selected Month :"<<month;
}


void MainWindow::on_pushButton_clicked()
{

}

