#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QCheckBox>
#include <QTimer>
using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->groupBox_2->hide();
    QTimer* timer = new QTimer(this); //to create a timer
    connect(timer, &QTimer::timeout, this, &MainWindow::updateLabel); //to connect the timer to update label slot
    timer->start(10000); // Update every 10 seconds

}

MainWindow::~MainWindow()
{
    delete ui;
}

QHash<QDate, QVector<QVector<QString>>> myHash; // hash with date as keys and nested vec as value for reminders
QVector<QString> ToDo; //dynamic array to store tasks


void MainWindow::on_push_Button_clicked() // to add reminders
{
    ui->remin->clear();

    QString title = ui->title->text();
    QString description = ui->desc->text();
    QTime time = ui->t1->time();
    QString strTime=time.toString("hh:mm:ss");
    QString email = ui->email->text();
    QDate date = ui->calendarWidget->selectedDate();
    QString formattedDate = date.toString("yyyy-MM-dd");
    QString dataString;
    dataString = QString();
    QVector<QString> dataArray; //vector with string of reminder details

    dataArray.append(title);
    dataArray.append(description);
    dataArray.append(strTime);
    dataArray.append(email);

    QVector<QVector<QString>> dateArray; // nested vector with string inside inner vector


    dateArray.append(dataArray);

    myHash[date]=dateArray;

    QVector<QVector<QString>> value = myHash.value(date); //value stores vector with reminders of a date

    for (const QVector<QString> &inner:value) //
    {
        dataString+="Date : "+formattedDate+"\n";
        dataString+="Title : "+inner[0]+"\n";
        dataString+="Description : "+inner[1]+"\n";
        dataString+="Time : "+inner[2]+"\n";
        dataString+="Email : "+inner[3]+"\n\n";
    }
    ui->remin->setText(dataString);
    ui->title->clear();
    ui->desc->clear();
    ui->email->clear();
    ui->lineEdit_6->clear();
}

void MainWindow::on_calendarWidget_clicked(const QDate &date) //to show reminders of date selected on calender
{
    ui->remin->clear();


    QString dataString;
    QVector<QVector<QString>> value = myHash.value(date);
    QString formattedDate = date.toString("yyyy-MM-dd");
    if (!value.isEmpty())
        {
            for (const QVector<QString> &inner:value)
            {
                dataString+="Date : "+formattedDate+"\n";
                dataString+="Title : "+inner[0]+"\n";
                dataString+="Description : "+inner[1]+"\n";
                dataString+="Time : "+inner[2]+"\n";
                dataString+="Email : "+inner[3]+"\n\n";
            }
            ui->remin->setText(dataString); // to show reminders of the selected date
        }
}

void MainWindow::on_pushButton_6_clicked() // to search reminder
{
    ui->remin->clear();

    int count=0; //to count number of matched reminders
    QString reminder; //to store reminder
    QString title = ui->lineEdit_6->text(); //take title of reminder
    QHash<QDate, QVector<QVector<QString>>>::const_iterator it; //to create a Qhash iterator it, :: is used for scope resolution
    for (it = myHash.constBegin(); it != myHash.constEnd(); ++it) //to iterate thru all dates
    {
        QDate key = it.key(); //get the date
        QString formattedDate = key.toString("yyyy-MM-dd"); // Define the format you want
        QVector<QVector<QString>> value = it.value(); //get all the reminders for that date
        for (const QVector<QString> &inner:value) //to iterate thru each reminder of a date 'key', &->reference to inner and does not make copy
        {
            QString title_1=inner[0];
            if (title_1==title)
            {
                count+=1;
                reminder+="Date : "+formattedDate+"\n";
                reminder+="Title : "+inner[0]+"\n";
                reminder+="Description : "+inner[1]+"\n";
                reminder+="Time : "+inner[2]+"\n";
                reminder+="Email : "+inner[3]+"\n\n";
            }
        }
    }
    if (count>0)
    {
        ui->remin->setText(reminder);
    }
    else
    {
        ui->remin->setText("No reminders found");
    }
    //ui->lineEdit_6->clear();
}

void MainWindow::on_pushButton_2_clicked() // to delete reminder
{
    ui->remin->clear();
    QString title = ui->lineEdit_6->text(); // title of reminder to delete
    int count = 0; // number of deleted reminders

    QHash<QDate, QVector<QVector<QString>>>::iterator it_del; // Use a non-const iterator to modify the hash
    for (it_del = myHash.begin(); it_del != myHash.end(); /* no need to increment here */) // Iterate through all dates
    {
        QVector<QVector<QString>>& value = it_del.value(); // Get all the reminders for that date by reference
        QVector<QVector<QString>>::iterator innerIt = value.begin(); // iterator for value vector
        while (innerIt != value.end()) // Iterate through each reminder of a date 'key'
        {
            QString title_1 = (*innerIt)[0];
            if (title_1 == title)
            {
                innerIt = value.erase(innerIt); // Remove the inner vector if title matches
                ++count;
            }
            else
            {
                ++innerIt;
            }
        }
        // Remove the date entry if all reminders for that date were deleted
        if (value.isEmpty())
        {
            it_del = myHash.erase(it_del);
        }
        else
        {
            ++it_del; // Move to the next date
        }
    }

    if (count > 0)
    {
        QString fin = QString::number(count);
        ui->remin->setText(fin + " reminder(s) deleted.");
    }
    else
    {
        ui->remin->setText("No reminders found.");
    }
    ui->lineEdit_6->clear();
}

void MainWindow::on_pushButton_3_clicked() //to edit reminder
{
    ui->groupBox_2->show();
    this->resize(1250, 600);
    int count=0;
    ui->remin->clear();
    QString title = ui->lineEdit_6->text(); //take title of reminder
    QHash<QDate, QVector<QVector<QString>>>::const_iterator it; //to create a Qhash iterator it
    for (it = myHash.constBegin(); it != myHash.constEnd(); ++it) //to iterate thru all dates
    {
        QDate key = it.key(); //get the date
        QVector<QVector<QString>> value = it.value(); //get all the reminders for that date
        for (const QVector<QString> &inner:value) //to iterate thru each reminder of a date 'key'
        {
            QString title_1=inner[0];
            if (title_1==title)
            {
                count+=1;
                ui->lineEdit->setText(inner[0]);//title
                ui->lineEdit_3->setText(inner[1]);//desc
                ui->timeEdit_3->setTime(QTime::fromString(inner[2])); //time
                ui->lineEdit_4->setText(inner[3]);//email
                break;
            }
        }
        if (count==1)
        {
            break;
        }
    }
}

void MainWindow::on_pushButton_5_clicked() //to update reminder
{
    ui->remin->clear();
    QString title = ui->lineEdit_6->text(); // title of reminder to delete
    //int count = 0; // number of deleted reminders

    QHash<QDate, QVector<QVector<QString>>>::iterator it_del; // Use a non-const iterator to modify the hash
    for (it_del = myHash.begin(); it_del != myHash.end(); /* no need to increment here */) // Iterate through all dates
    {
        QVector<QVector<QString>>& value = it_del.value(); // Get all the reminders for that date by reference
        QVector<QVector<QString>>::iterator innerIt = value.begin(); // iterator for value vector
        while (innerIt != value.end()) // Iterate through each reminder of a date 'key'
        {
            QString title_1 = (*innerIt)[0];
            if (title_1 == title)
            {
                innerIt = value.erase(innerIt); // Remove the inner vector if title matches
                //++count;
            }
            else
            {
                ++innerIt;
            }
        }
        // Remove the date entry if all reminders for that date were deleted
        if (value.isEmpty())
        {
            it_del = myHash.erase(it_del);
        }
        else
        {
            ++it_del; // Move to the next date
        }
    }

    ui->remin->clear();

    QString title2 = ui->lineEdit->text();
    QString description2 = ui->lineEdit_3->text();
    QTime time2 = ui->timeEdit_3->time();
    QString strTime=time2.toString("hh:mm:ss");
    QString email2 = ui->lineEdit_4->text();
    QDate date = ui->calendarWidget->selectedDate();
    QString formattedDate = date.toString("yyyy-MM-dd");
    QString dataString;
    dataString = QString();
    QVector<QString> dataArray; //vector with string of reminder details

    dataArray.append(title2);
    dataArray.append(description2);
    dataArray.append(strTime);
    dataArray.append(email2);

    QVector<QVector<QString>> dateArray; // nested vector with string inside inner vector


    dateArray.append(dataArray);

    myHash[date]=dateArray;

    QVector<QVector<QString>> value = myHash.value(date); //value stores vector with reminders of a date

    for (const QVector<QString> &inner:value) //
    {
        dataString+="Date : "+formattedDate+"\n";
        dataString+="Title : "+inner[0]+"\n";
        dataString+="Description : "+inner[1]+"\n";
        dataString+="Time : "+inner[2]+"\n";
        dataString+="Email : "+inner[3]+"\n\n";
    }
    ui->label_11->setText(dataString);
    ui->remin->setText("Updated successfully");
}

void MainWindow::on_pushButton_4_clicked() //cancel update
{
    ui->groupBox_2->hide();
    this->resize(980, 600);
}

void MainWindow::on_pushButton_7_clicked() //close after update
{
    ui->groupBox_2->hide();
    this->resize(980, 600);
    ui->label_11->clear();
}

void MainWindow::on_pushButton_clicked() // to add task to To-Do list
{
    QString task=ui->lineEdit_7->text();
    QCheckBox * newCheckbox = new QCheckBox(task, this);
    newCheckbox->setChecked(false);
    ui->verticalLayout->addWidget(newCheckbox);
    ui->lineEdit_7->clear();
}

void MainWindow::on_pushButton_8_clicked() // to delete task from To-Do list
{
    QString taskToDelete = ui->lineEdit_7->text(); // Get the text input for the task to delete

    // Iterate through the widgets in the vertical layout
    for (int i = 0; i < ui->verticalLayout->count(); ++i)
    {
        QCheckBox* checkbox = qobject_cast<QCheckBox*>(ui->verticalLayout->itemAt(i)->widget());
        if (checkbox && checkbox->text() == taskToDelete)
        {
            // If a checkbox with matching text is found, remove it from the layout and delete it
            ui->verticalLayout->removeWidget(checkbox);
            delete checkbox;
            break; // Exit the loop after deleting the checkbox
        }
    }
    ui->lineEdit_7->clear();
}

void MainWindow::updateLabel() //to show quotes dynamically with timer
{
    static int currentIndex = 0;
    const QStringList textArray = {
                "Believe you can, and you're halfway there. - Theodore Roosevelt",
                "Don't watch the clock; do what it does. Keep going. - Sam Levenson",
                "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
                "Hard work beats talent when talent doesn't work hard. - Tim Notke",
                "The only way to do great work is to love what you do. - Steve Jobs",
                "You are never too old to set another goal or to dream a new dream. - C.S. Lewis",
                "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
                "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt",
                "What lies behind us and what lies before us are tiny matters compared to what lies within us. - Ralph Waldo Emerson",
                "Your time is limited, so don't waste it living someone else's life. - Steve Jobs",
                "It always seems impossible until it's done. - Nelson Mandela",
                "Don't be pushed around by the fears in your mind. Be led by the dreams in your heart. - Roy T. Bennett",
                "The harder you work for something, the greater you'll feel when you achieve it. - Unknown",
                "You miss 100% of the shots you don't take. - Wayne Gretzky",
                "The only way to do great work is to love what you do. - Steve Jobs",
                "Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful. - Albert Schweitzer",
                "The biggest risk is not taking any risk. In a world that is changing quickly, the only strategy that is guaranteed to fail is not taking risks. - Mark Zuckerberg",
                "The only person you are destined to become is the person you decide to be. - Ralph Waldo Emerson",
                "You have within you the strength, the patience, and the passion to reach for the stars to change the world. - Harriet Tubman",
                "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle. - Christian D. Larson"
            };


    // Update the label text with the current string from the array
    ui->label_5->setText(textArray[currentIndex]);

    // Increment the index for the next iteration
    currentIndex = (currentIndex + 1) % textArray.size();
}


